const express = require("express");
const prisma = require("../prisma/client");
const { validationResult } = require("express-validator");
const bcrypt = require("bcryptjs/dist/bcrypt");

const findUser = async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
      },
      orderBy: {
        id: "desc",
      },
    });

    res.status(200).send({
      success: true,
      message: "Data user berhasil diambil.",
      data: users,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Gagal mengambil data user",
    });
  }
};

const createUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: "Error validasi.",
      errors: errors.array(),
    });
  }

  const hashedPassword = await bcrypt.hash(req.body.password, 10);
  try {
    const user = await prisma.user.create({
      data: {
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword,
      },
    });

    res.status(200).send({
      success: true,
      message: "User berhasil ditambahkan.",
      data: user,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Gagal menambahkan user.",
    });
  }
};

const findUserById = async (req, res) => {
  const { id } = req.params;

  try {
    const user = await prisma.user.findUnique({
      where: {
        id: Number(id),
      },
      select: {
        id: true,
        name: true,
        email: true,
      },
    });

    res.status(200).send({
      success: true,
      message: `Mengambil data user dengan ID: ${id}`,
      data: user,
    });
  } catch (error) {
    res.status(500).send({
      status: false,
      message: "Gagal mengambil data user.",
    });
  }
};

const updateUser = async (req, res) => {
  const { id } = req.params;

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: "Error validasi.",
      errors: errors.array(),
    });
  }

  const hashedPassword = await bcrypt.hash(req.body.password, 10);

  try {
    const user = await prisma.user.update({
      where: { id: Number(id) },
      data: {
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword,
      },
    });

    res.status(200).json({
      success: true,
      message: `Berhasil update user dengan ID: ${id}`,
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal mengupdate user.",
    });
  }
};

const deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    await prisma.user.delete({
      where: {
        id: Number(id),
      },
    });

    res.status(200).send({
      success: true,
      message: `User dengan ID: ${id} berhasil dihapus`,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal menghapus user.",
    });
  }
};

module.exports = { findUser, createUser, findUserById, updateUser, deleteUser };
