const express = require("express");
const { validationResult, body } = require("express-validator");
const bcrypt = require("bcryptjs");
const prisma = require("../prisma/client");

const register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: "Error validasi.",
      errors: errors.array(),
    });
  }

  const hashedPassword = await bcrypt.hash(req.body.password, 10);

  try {
    const user = await prisma.user.create({
      data: {
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword,
      },
    });

    res.status(201).send({
      success: true,
      message: "Pendaftaran berhasil.",
      data: user,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Gagal membuat data user.",
    });
  }
};

module.exports = { register };
