const { body } = require("express-validator");
const prisma = require("../../prisma/client");

const validateRegister = [
  body("name").notEmpty().withMessage("Nama harus diisi."),
  body("email")
    .notEmpty()
    .withMessage("Email harus diisi.")
    .isEmail()
    .withMessage("Eamil tidak valid")
    .custom(async (value) => {
      if (!value) {
        throw new Error("Email harus diisi.");
      }
      const user = await prisma.user.findUnique({ where: { email: value } });
      if (user) {
        throw new Error("Email sudah terdaftar.");
      }
      return true;
    }),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Password minimal 6 karakter."),
];

const validateLogin = [
  body("email").notEmpty().withMessage("Email harus diisi."),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Password minimal 6 karakter."),
];

module.exports = { validateRegister, validateLogin };
