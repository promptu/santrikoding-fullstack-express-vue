const { body } = require("express-validator");
const prisma = require("../../prisma/client");

const validateUser = [
  body("name").notEmpty().withMessage("Nama harus diisi."),
  body("email")
    .notEmpty()
    .withMessage("Email harus diisi.")
    .isEmail()
    .withMessage("Email tidak valid.")
    .custom(async (value, { req }) => {
      if (!value) {
        throw new Error("Email harus diisi.");
      }
      const user = await prisma.user.findUnique({ where: { email: value } });
      if (user && user.id !== Number(req.params.id)) {
        throw new Error("Email sudah terdaftar.");
      }
      return true;
    }),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Password minimal 6 karakter."),
];

module.exports = { validateUser };
